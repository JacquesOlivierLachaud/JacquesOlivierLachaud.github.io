// tetris.h
#ifndef _TETRIS_H_
#define _TETRIS_H_

/* Constantes. */
#define HAUTEUR 15
#define LARGEUR 10
#define NB_PIECES 3
/* ... */

/* Types. */
typedef char Grille[ HAUTEUR ][ LARGEUR ];
typedef struct SPiece {
} Piece;
/* ... */

/* Fonctions. */
extern void genererPieces( Piece tabPiece[ NB_PIECES ] );
extern void affichePieces( Piece p );
extern char lireCase( Grille G, int ligne, int colonne );
/* ... */

#endif /* ifndef _TETRIS_H_ */
