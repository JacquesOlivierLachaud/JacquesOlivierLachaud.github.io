// gtktetris.c
#include <stdlib.h>
#include <math.h>
#include <gtk/gtk.h>
#include "tetris.h"

int main( int   argc,
          char *argv[] )
{
    GtkWidget *window;

    /* Passe les arguments à GTK, pour qu'il extrait ceux qui le concernent. */
    gtk_init (&argc, &argv);
    
    /* Crée une fenêtre. */
    window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
    /* La rend visible. */
    gtk_widget_show  (window);
    
    /* Rentre dans la boucle d'événements. */
    /* Tapez Ctrl-C pour sortir du programme ! */
    gtk_main ();
    return 0;
}
