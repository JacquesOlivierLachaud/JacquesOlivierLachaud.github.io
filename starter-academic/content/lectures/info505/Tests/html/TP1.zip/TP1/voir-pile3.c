#include <stdio.h>

#define MAX 10000

void recurs(char a, char b, char c)
{ // les paramètres 'a' et 'c' servent uniquement à repérer visuellement
  //   le paramètre 'b' qui lui est modifié au cours des appels récursifs. 
    if ( b > '0' ) {
        // Récursion avec une valeur inférieure en b 
        recurs( a, b-1, c );
    } else {
        // Cas de base, b vaut '0'.
        int t = 65; // on se donne une variable locale 
        char* p = (char*) &t; // permet de voir la mémoire caractère par car. 
        for ( int i=0; i < MAX; ++i ) {
            printf("%c", p[ i ] );
            fflush( stdout );
        }
    }
}

int main( void )
{
  recurs('-','9','-');
  return 0;
} 

