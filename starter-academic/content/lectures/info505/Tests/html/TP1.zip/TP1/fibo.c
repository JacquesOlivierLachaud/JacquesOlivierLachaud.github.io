#include <stdio.h>

int fibo(int n) {
    if(n <= 1) {
        return 1;
    }
    int f1 = fibo(n-1);
    int f2 = fibo(n-2);
    int res = f1 + f2;
    return res;
}

int main() {
    for(int i = 0; i < 10; i++) {
        printf("fibo %i : %i\n", i, fibo(i));
    }
    return 0;
}
