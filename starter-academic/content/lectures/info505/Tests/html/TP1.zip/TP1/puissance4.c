
#include <stdlib.h>
#include <stdio.h>



typedef char Jeu [6][7];


/**
 * Affiche l'état actuel du jeu.
 */
void affiche(Jeu g){}

/**
 * Initialise la grille.
 */
void init (Jeu g){}

/**
 * Teste si la colonne c de la grille a encore de la place.
 */
int n_est_pas_pleine (int c, Jeu g){}

/**
 * Modifie la grille lorsque le joueur p joue dans la colonne c.
 */
void joue (int j, int c, Jeu p){}


/**
 * Programme principal.
 *
 */
int main()
{
  int e,p;
  e=1;  					/* stock le dernier caractère entré par l'utilisateur */
  p=1; 	 				/* indique le joueur qui doit jouer */
  while (e!=0) {				/* on ne quitte le jeu que quand l'utilisateur entre 0 */
    affiche(game);
    printf("Quelle colonne joue le joueur %d ? (0 pour sortir)",p);
    scanf("%d", &e);			/* le joueur entre la colonne ou il souhaite jouer */
    if (e!=0 ){  		
      if (n_est_pas_pleine(e-1,game)) {  	/* on doit tester si la colonne est déja pleine ou non */
        joue(p,e-1,game);			/* on met a jour la grille */
        p=3-p;				/* le joueur courant change */
      }
      else {
        printf("C'est impossible !");
      };
    }   
  }
  return 0;
}

