// yolo_tp.cpp
#include <opencv2/core.hpp>
#include <opencv2/dnn.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>

#include <algorithm>
#include <chrono>
#include <cmath>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

struct Detection {
    cv::Rect2d box;
    float score;
    int classId;
};

int main(int argc, char** argv)
{
    const std::string filename = argc > 1 ? argv[1] : "horse.jpg";
    const cv::Mat image = cv::imread(filename);
    if (image.empty()) {
        std::cerr << "Image illisible : " << filename << '\n';
        return 1;
    }

    std::ifstream labels("coco.names");
    std::vector<std::string> classes;
    for (std::string name; std::getline(labels, name); ) {
        if (!name.empty() && name.back() == '\r')
            name.pop_back();
        classes.push_back(name);
    }
    if (classes.size() != 80) {
        std::cerr << "coco.names doit contenir les 80 noms de classes.\n";
        return 1;
    }

    constexpr int inputSize = 416;
    const cv::Mat blob = cv::dnn::blobFromImage
      ( image, 1.0 / 255.0, cv::Size(inputSize, inputSize),
        cv::Scalar(), true, false);
    cv::dnn::Net net = cv::dnn::readNetFromONNX("yolov3.onnx");
    net.setInput(blob);
    const std::vector<cv::String> names{
      "convolution_output2", "convolution_output1", "convolution_output"};
    std::vector<cv::Mat> outputs;
    const auto start = std::chrono::steady_clock::now();
    net.forward(outputs, names);
    const std::chrono::duration<double> elapsed =
      std::chrono::steady_clock::now() - start;
    std::cout << "OpenCV " << CV_VERSION << '\n'
              << "Inférence : " << elapsed.count() << " s\n";
    for (const auto& out : outputs) {
      std::cout << "Sortie :";
      for (int d = 0; d < out.dims; ++d)
        std::cout << ' ' << out.size[d];
      std::cout << '\n';
    }
    // Ajoutez ici le décodage, le filtrage et l’affichage.
    
}
