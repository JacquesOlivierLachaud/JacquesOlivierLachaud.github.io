#include <stdio.h>
#include <stdlib.h>

int main() 
{
int colonne;
char str[ 8 ];
while ( 1 ) {
  printf( "(g)auche, (d)roite ou (0-14) colonne: " );
  if ( scanf( "%7s", str ) == 1 ) {
  if ( str[ 0 ] == 'g' ) {  printf( "gauche\n" ); }
  else if ( str[ 0 ] == 'd' ) {  printf( "droite\n" ); }
  else {
    colonne = atoi( str );
    printf( "colonne=%d\n", colonne ); }
  }
}
  return 0;
}
