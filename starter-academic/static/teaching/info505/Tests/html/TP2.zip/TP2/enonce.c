/**
 *
 * \page tp2 TP2 - Mini-projet Tetris simplifié
 *
 * \section TP2-intro 1 - Objectifs
 *
 * L'objectif de ce TP, ainsi que du prochain, est de réaliser une version
 * simplifiée du jeu Tetris. Si vous ne connaissez pas ce jeu, vous pouvez en
 * apprendre les principes à l'adresse :
 *
 * http://fr.wikipedia.org/wiki/Tetris
 *
 * Il est important de LIRE ATTENTIVEMENT ET EN ENTIER CE DOCUMENT AVANT DE
 * COMMENCER A CODER!! 
 *
 * L'idée ici est de faire un jeu Tetris console, qui codera toute la
 * logique du jeu, sans les aspects graphiques ni temps réel. Ces deux
 * derniers aspects seront traités dans le TP suivant (\ref tp3). Ici,
 * l'objectif est de vous faire travailler sur les structures de
 * données, avec d'abord une représentation \b tableau \b à \b 2 \b
 * dimensions, puis ensuite une représentation \b liste, pour stocker
 * la grille du tetris.
 *
 * Plusieurs contraintes sur la structure de votre programme vous sont imposées.
 *
 * Pour ce TP, vous devrez remettre au moins trois fichiers sous forme d'archive:
 * `tp2-tableau.c`, `tp2-liste.c`, et un `README.txt`. Les
 * points suivants seront évalués :
 *
 *  - Le README.txt *doit* indiquer quelles questions vous avez
 *    complètement traitées, et quelles questions ont été abordées (en
 *    précisant les problèmes ou erreurs). Vous perdrez des points
 *    sans ce fichier README, où si les informations données ne
 *    coincident pas avec le code rendu.
 *
 *  - La lisibilité de votre programme (choix pertinent pour les noms de
 *    variables, indentation, etc.),
 *
 *  - Chaque fichier devra comporter un commentaire au début avec vos nom,
 *    prénom, filière, intitulé du cours et numéro de TP,
 *
 *  - Votre code devra compiler avec `gcc` sans erreurs ni warnings, et
 *    fonctionner sous Linux.
 *
 *  - Toute mémoire allouée devra être libérée.
 *
 *  - Ce TP peut être fait par binôme (mais mettez les deux noms !). 
 * 
 *  - Vous m'enverrez une première version de votre TP à la fin de votre
 *    séance de TP (dépend des groupes), via <a
 *    href="https://tplab.apps.math.cnrs.fr">TPLab</a>. Vous
 *    aurez 7 jours ensuite pour envoyer une version finale (dépend des groupes aussi).  Il faudra une archive (ZIP, ou TAR.GZ) nommée TP2-[votre
 *    ou vos nom(s)] contenant tous les fichiers sources, entêtes, le
 *    README mis à jour, éventuellement un makefile.
 *
 * [TOC]
 *
 *
 * \section TP2-jeu 2 - Une version simplifiée du jeu Tetris
 *
 * Dans le cadre de ce TP, le jeu sera implémenté uniquement en texte
 * et son déroulement se fera entièrement dans le terminal. Vous aurez
 * ainsi toute la partie logique du jeu qui fonctionne à la fin du
 * TP. Pour cette partie, vous écrirez tout dans un fichier
 * `tp2-[votre nom]-tableau.c`
 *
 * @note Vous étofferez votre jeu en mode graphique temps-réel à la
 * séance suivante. 
 *
 * Tout d'abord nous allons simplifier grandement le déroulement du jeu.
 * 
 *  1. L'interactivité du jeu sera réduite au minimum :
 *  - La lecture du clavier étant effectuée à l'aide de la commande "scanf" aucun
 *    délai n'est imposé au joueur.
 *
 * \code
int colonne;
scanf( "%d", &colonne );
 * \endcode
 *
 *  - Lorsqu'un joueur a choisi la colonne dans laquelle faire tomber la
 *    pièce, celle-ci est directement ajouté à la position la plus basse qu'elle
 *    peut atteindre.
 *
 *    Voici un exemple :
 *    \code
         @ 
        @@@
        ↑
  ||               ||
  ||               ||
  ||               ||
  ||               ||
  ||               ||
  ||               ||
  ||               ||
  ||               ||
  ||               ||
  ||               ||
  |||||||||||||||||||
    012345678901234

Dans quelle colonne placer cette piece?
> 
 * \endcode
 *
 * Si le joueur choisit, par exemple, la colonne 8 alors la pièce est insérée de
 * manière à ce que sa colonne la plus à gauche  (celle indiquée par une flèche
 * dans l'exemple) soit dans la colonne #8. 
 *
 * \code
Dans quelle colonne placer cette piece?
> 8  

         l
         l
         l
         l
         ↑
  ||               ||
  ||               ||
  ||               ||
  ||               ||
  ||               ||
  ||               ||
  ||               ||
  ||               ||
  ||         @     ||
  ||        @@@    ||
  |||||||||||||||||||
    012345678901234

Dans quelle colonne placer cette piece?
> 
 * \endcode  
 *
 * Par convention, la grille de jeu est modélisée de \b bas \b en \b
 * haut, c'est-à-dire que la \b ligne \b 0 \b est \b en \b bas, la ligne 1 est juste
 * au-dessus, etc. Attention, pour l'affichage sur la console, il
 * faudra donc partir de la dernière ligne et afficher jusqu'à la
 * première ligne. Ci-dessous, vous avez à gauche le numéro de ligne
 * et en bas le numéro de colonne de chaque case. Les barres `|` ne
 * font pas partie de la grille et sont juste affichés.
 *
 * \code
9 ||               ||
8 ||               ||
7 ||               ||
6 ||               ||
5 ||               ||
4 ||               ||
3 ||               ||
2 ||               ||
1 ||         @     ||
0 ||        @@@    ||
  |||||||||||||||||||
    0         1    
    012345678901234
 * \endcode  
 *
 * \note Dans un \b premier \b temps, les pièces sont dessinées de
 * manière à ce que la ligne la plus basse soit continue et au moins
 * aussi large que toutes les autres au-dessus.
 *
 * \code
       l
       l      R                  LL  Z         
   @   l  $$  R             @@@   L  ZZ       
  @@@  l  $$  RR ...         @    L   Z       

  pièces valides         pièces non-valides
 * \endcode
 *
 * Comme nous le verrons plus tard, cette contrainte simplifie grandement le
 * positionnement des pièces.
 * 
 * Remarques : 
 *  - Les bords de la grille de jeu sont représentés par le symbole ``'|'`` (pipe)
 *  - Les pièces sont représentées à l'aide de n'importe quels caractères autre
 *  qu'un espace (``' '``) ou un pipe (``'|'``).
 *
 * 
 * \section TP2-prog 3 - Réalisation du programme en C
 *
 * \subsection TP2-constantes 3.1 - Constantes
 *
 * Déclarez 4 constantes avec la directive \c \#define : 
 *  - HAUTEUR : le nombre de lignes de l'espace de jeu. On la fixe à 10.
 *  - LARGEUR : le nombre de colonnes de l'espace de jeu. On la fixe à 15.
 *  - NB_PIECES : le nombre de pièces différentes. À fixer en fonction du nombre de pièces
 *  que vous déciderez d'include.
 *  - HAUTEUR_MAX_DES_PIECES : le nombre maximum de lignes qui peut occuper une
 *  pièce. On fixe cette valeur à 4.
\code
#define HAUTEUR 4
...
typedef char Grille[ HAUTEUR ][ LARGEUR ];
\endcode
 * 
 * \subsection TP2-types 3.2 - Nouveaux types
 *
 * - \c Piece : une struct contenant les champs suivants 
 *    - \c hauteur : le nombre de lignes qu'occupe la pièce.
 *    - \c largeur : le nombre de colonnes qu'occupe la pièce.
 *    - \c forme : un tableau de chaînes de caractères, permettant de dessiner la
 *    pièce. Ce sera un tableau de HAUTEUR_MAX_DES_PIECES cases, chaque case étant 
 *    de type \c char*, qui pointe donc vers une chaîne de caractères.
 *
 * \code
struct SPiece {
  int   hauteur;
  int   largeur;
  char* forme[ HAUTEUR_MAX_DES_PIECES ];
};
typedef struct SPiece Piece;
 * \endcode
 *
 * - \c Grille : Un tableau bidimensionnel de caractères qui représente l'espace de jeu.
 *
 * \subsection TP2-affichage 3.3 - Initialisation et affichage de la grille
 *  
 * - Écrivez une procédure `void initialiseGrille( Grille G )` qui remplit une grille
 * de jeu `G` passé en paramètre avec le caractère ``' '`` (espace).
 *  
 * - Écrivez une procédure `char lireCase( Grille G, int i, int j )`
 *  qui, pour une grille, un numéro de ligne et un numéro de colonne
 *  passés en paramètre, retourne le contenu de la case correspondante
 *  de cette grille. Vous devez toujours utiliser cette procédure
 *  lorsque vous voulez lire le contenu d'une case la grille de jeu.
 *  Ajoutez dans cette procédure un test vérifiant que la ligne et la
 *  colonne sont valides. Si tel n'est pas le cas, une erreur doit
 *  être affichée.
 *
 * - Écrivez une procédure ` void afficheGrille( Grille G )` afin d'afficher le
 *  contenu d'une grille donnée en entrée en l'encadrant à gauche, à
 *  droite et en dessous avec le caractère ``'|'`` (pipe). Ajoutez
 *  également des nombres qui indiquent le numéro de chacune des
 *  colonnes (voir l'exemple plus haut).
 *  
 * - Écrivez une procédure `main` qui vous permet de tester le
 *  fonctionnement des deux procédures précédentes. C'est au début du
 *  `main` qu'il faudra instancier une grille.
 *
 *  \b TESTEZ \b VOTRE \b PROGRAMME \b À \b CHAQUE \b ÉTAPE \b DE \b SON \b DÉVELOPPEMENT!!
 *
 * \subsection TP2-pieces 3.4 - Génération et affichage des pièces
 *
 * - Écrivez une procédure \c générerPieces qui initialise un tableau
 *  de pièce avec chacune des pièces qui apparaîtront dans le jeu. Les
 *  pièces sont écrites une par une "à la main" dans cette fonction.
 *  Voici un exemple d'initilisation de pièces :
 *  \code
    tabPiece[0].hauteur = 4;
    tabPiece[0].largeur = 1;
    tabPiece[0].forme[3] = "I";
    tabPiece[0].forme[2] = "I";
    tabPiece[0].forme[1] = "I";
    tabPiece[0].forme[0] = "I";
    tabPiece[1].hauteur = 2;
    tabPiece[1].largeur = 3;
    tabPiece[1].forme[1] = " @ ";
    tabPiece[1].forme[0] = "@@@";
    ...
 * \endcode
 *
 * Il est important que chacune des chaînes de caractères du tableau
 * \c forme aient exactement la même taille, cette taille étant la
 * valeur donnée au champs \c largeur (1 ou 3 dans cet exemple). Votre jeu
 * doit fournir au moins cinq pièces différentes, à vous de décider
 * lesquelles. Notez que comme le joueur ne peut pas \b encore tourner
 * les pièces, les quatre pièces suivantes sont considérées comme
 * étant différentes :
 *
 * \code 
  #         #        
  #         #         #        #
  ##       ##       ###        ###
 * \endcode
 *
 * - Faites impérativement la pièce verticale de 4 et la pièce 2x2, elles sont bien pratiques pour tester le tetris.
\verbatim
l
l
l    %%
l    %%
\endverbatim
 *
 * - Écrivez une procédure \c affichePiece qui affiche une pièce passée en paramètre et
 *   ajoute une flèche (ou tout autre symbole) sous la colonne la plus à gauche
 *   de manière à indiquer au joueur où sera inséré la pièce.
 *   \code
         @ 
        @@@
        ↑
 *   \endcode
 *
 *
 * \subsection TP2-ecriture 3.5 - Écriture dans la grille
 *
 * - Écrivez une procédure `void ecrireCase( Grille G, int i, int j,
 *   char c )` qui, pour une grille, un numéro de ligne et un numéro
 *   de colonne passés en paramètre, inscrit dans la case
 *   correspondante de la grille de jeu un caractère également
 *   spécifié en paramètre. Vous devez toujours utiliser cette
 *   procédure pour écrire dans la grille de jeu. Il est là aussi
 *   fortement conseillé de tester la validité des numéros de ligne et
 *   colonne et d'afficher une erreur dans le cas contraire.
 *
 * Lorsqu'un joueur décide de placer une pièce dans une colonne donnée, il
 * faut être en mesure de déterminer à quelle hauteur la pièce sera déposée. On
 * a imposé une forme particulière aux pièces de manière à simplifier cette
 * étape. Comme la ligne la plus basse d'une pièce est forcément la plus large,
 * il suffit de déterminer, pour chacune des colonnes que va occuper cette
 * pièce, quelle est hauteur de la plus haute case occupée.
 * 
 * - Écrivez une procédure `int hauteurPlat( Grille g, int c1, int c2
 *   )` qui, étant donné une grille et un intervalle de colonnes,
 *   retourne la ligne la plus basse où on peut placer une pièce sans
 *   écraser une pièce déjà placée. C'est équivalent à retourner un
 *   plus la hauteur maximale où se trouve une case occupée entre les
 *   colonnes spécifiées. Cette procédure sera mise à jour dans un \b
 *   deuxième \b temps pour prendre en compte des pièces plus
 *   complexes (voir `hauteurExacte` plus loin).
 * 
 * - Écrivez une procédure `void ecrirePiece( Grille G, Piece P, int
 *   c, int h )` qui reçoit en paramètre une grille, une pièce, un
 *   numéro de colonne ainsi qu'une hauteur et ajoute cette pièce à la
 *   grille de manière à ce que la colonne la plus à gauche de la
 *   pièce corresponde au numéro de colonne spécifiée.
 *   @warning Faites bien
 *   attention à ne \b rien \b écrire là où la pièce est vide (ie. un
 *   espace). Ce sera important pour la section \ref
 *   TP2-pieces-complexes.
 *
 * \subsection TP2-lecture 3.6 - Lecture des entrées
 *
 * - Écrivez une procédure \c pieceAleatoire qui choisit une pièce au hasard
 *  parmi celles que vous avez définies.
 *  Pour choisir un nombre aléatoirement dans l'ensemble {0,1,2,...,n-1} on
 *  peut utiliser la commande suivante : 
 *  \code
    #include <stdlib.h>
    ...
    int alea = (int)(((double)random()/((double)RAND_MAX)) * (NB_PIECES));
 * \endcode
 *
 * - Modifiez la fonction \c main en y ajoutant une boucle principale de manière
 *  à : 
 *   - Afficher une pièce choisie aléatoirement,
 *   - Affiche la grille de jeu,
 *   - Demande à l'utilisateur d'entrer le numéro de la colonne où il veut
 *   mettre la pièce,
 *   - Ajoute la pièce à la grille de jeu.
 *   - Répéter les étapes précédentes jusqu'à ce que l'utilisateur entre la
 *    valeur -1 indiquant qu'il souhaite quitter le programme.
 *
 * \note Vous noterez que l'aléatoire ne semble pas si aléatoire que
 * ça, avec toujours la même suite de pièces successives. C'est voulu
 * ! En fait, ce sont des suites pseudo-aléatoires, c'est-à-dire
 * qu'elles donnent des résultats déterministes. Si on veut un peu
 * plus d'aléatoire, on change alors la graine (\a seed en anglais) du
 * générateur pseudo-aléatoire pour l'initialiser à une valeur
 * différente à chaque run. Par exemple, on peut mettre au début de la
 * fonction `main` :
 * \code
 #include <time.h>
 ...
 int main(...)
 {
   srand( time( NULL ) );
   ...
 * \endcode
 *
 * \subsection TP2-fin 3.7 - Détection de la fin de la partie
 *  
 * - Modifiez votre code de manière à ce qu'avant de faire une appel à \c
 *  ecrirePiece votre programme détecte si la pièce va dépasser de la grille de
 *  jeu. Si tel est le cas, on affiche un message informant le joueur qu'il a
 *  perdu la partie ainsi que le nombre de pièces qu'il a réussi à placer. La
 *  grille est alors réinitialisée et une nouvelle partie démarre.
 *
 * \subsection TP2-effacement 3.8 - Effacement de lignes
 *
 * - Écrivez une procédure `void supprimerLigne( Grille G, int i )`
 *   qui efface le contenu d'une ligne dont le numéro est passé en
 *   paramètre et fait descendre toutes celles au-dessus.  Plus
 *   précisément, lorsqu'une ligne est ``supprimée``, le contenu de
 *   chacune des lignes au dessus de celle-ci doit être recopié dans
 *   la ligne d'en dessous et la ligne la plus haute de la grille de
 *   jeu est remplacée par une ligne vide.
 *
 * - Écrivez une fonction `int nettoyer( Grille G )` qui supprime toutes les lignes
 *   ne contenant aucune case vide et qui retourne le nombre de lignes
 *   supprimées (utile si on veut gérer le score).
 *
 * - Modifiez votre code de manière à ce qu'à chaque fois que le joueur place
 *   une pièce, un appel à `nettoyer` soit effectué.
 *
 *   
 * Vous devriez avoir maintenant une version _jouable_. Malheureusement,
 * les pièces étant toutes plus larges à la base, vous allez voir qu'il
 * est difficile de gagner à ce Tetris.
 *
 * \subsection TP2-pieces-complexes 3.9 - Pièces générales
 *
 * On autorise maintenant le type de pièces ci-dessous:
 * \code
                       LL                  Z         
 @@@                    L                  ZZ       
  @                     L                   Z       
 * \endcode
 *
 * Il n'est plus suffisant d'utiliser \c hauteurPlat pour détecter la
 * position où va tomber la pièce. On peut juste dire que \c
 * hauteurPlat donne la "pire" hauteur possible, mais potentiellement
 * la pièce peut aller plus bas. Ecrivez donc la fonction
 *
 * \code
 int hauteurExacte( Grille g, int col_gauche, Piece* piece );
 * \endcode
 *
 * qui vous retourne cette hauteur exacte. Substituez ensuite \c
 * hauteurExacte à \c hauteurMax dans le code. Si la procédure \c
 * ecrirePiece est correctement écrite, alors cela devrait fonctionner
 * du premier coup.
 *
 * @note L'idée est de calculer colonne par colonne de la pièce à
 * quelle hauteur on peut poser la pièce. Ensuite, la hauteur où on
 * peut poser est le maximum des hauteurs calculées pour chaque
 * colonne.
\verbatim
H   01      colonne piece
    ##        0 : hauteur_grille(2+0) = 3, hauteur_piece(0) = 2
     #          => hauteur_exacte(0) = 3 - 2 = 1
     #        1 : hauteur_grille(2+1) = 2, hauteur_piece(1) = 0
                => hauteur_exacte(1) = 2 - 0 = 2
3        L    => hauteur_exacte = max(1,2) = 2
2  AA  AAL
1  LLLLAAL
0 BBAABBAA
  01234567  colonne grille     
\endverbatim
 *
 * \subsection TP2-tourner-les-pieces 3.10 - Tourner les pieces
 *
 * On peut aussi implémenter les rotations. Cela se fait simplement en
 * créant les rotations d'une pièce comme autant de pièces
 * différentes. On mémorise ensuite dans un tableau `rotD` que la
 * rotation d'une pièce à droite donne le numéro d'une autre pièce et
 * similairement avec un tableau `rotG`. Enfin, l'utilisateur tape 'g'
 * ou 'd' pour tourner la pièce avant de choisir la colonne.  La
 * lecture au clavier se fera plutôt en lisant une chaîne de
 * caractères et en l'analysant. En pseudo-code, ça peut ressembler à ça:
 *
 * \code
...
int colonne;
char str[ 8 ];
while ( 1 ) {
  printf( "(g)auche, (d)roite ou (0-14) colonne: " );
  if ( scanf( "%7s", str ) == 1 ) {
  if ( str[ 0 ] == 'g' ) {  tourne à gauche la piece }
  else if ( str[ 0 ] == 'd' ) {  tourne à droite la piece }
  else {
    colonne = atoi( str );
    break;
  }
  réaffiche la pièce
}
...
 * \endcode
 *
 * @note Les tableaux rotD et rotG sont de simples tableaux d'entiers,
 * pour aller de numéro de pièces en numéro de pièces. Par exemple,
 * dans la situation suivante, on aurait :
 *
 * \code
      #                ##        
      #         #       #       ###      %%
      ##      ###       #       #        %%   ...
n°    0        1        2        3        4
rotG  1        2        3        0        4
rotD  3        0        1        2        4   ...
 * \endcode
 *
 *
 * \section TP2-liste 4 - Implémentation à l'aide d'une liste chaînée
 *
 * Cette partie est à faire dans un deuxième temps, une fois que le
 * tetris "tableau" fonctionne (en effet, il servira pour le tetris
 * graphique).
 *
 * On propose une autre structure de données pour représenter la
 * grille de jeu, où chaque ligne est indépendante des autres et où
 * elles sont placées dans une liste chaînée. Ainsi, lorsqu'une ou
 * plusieurs lignes seront supprimées, il suffira de supprimer un ou 
 * des éléments de la liste, les autres lignes seront donc
 * automatiquement déplacées. Pour cela, nous allons remplacer le
 * tableau servant à représenter la grille de jeu par une liste
 * doublement chaînée.
 *
 * - Commencez par effectuer une copie de sauvegarde de votre code. Appelez ce
 *   fichier \code 
     tp2-[votre nom]-tableau.c
 *   \endcode
 *
 * Avant de modifier votre code, récupérez les codes suivants (Liste.h, Liste.c, test-Liste.c), compilez-les avec
\code
gcc Liste.c test-Liste.c -o test-Liste
\endcode
 * et exécutez le programme.
 *
 * \include Liste.h
 * \include Liste.c
 * \include test-Liste.c
 *
 * On constate que, contrairement à ce que l'on espérerait, la commande
 * \c affiche(L) n'affiche rien du tout.
 * 
 *  - Utilisez un débogueur (par exemple : ddd), afin de corriger cette
 *  implémentation de liste chaînées.
 *
 *  - Assurez-vous que ces listes libèrent toute la mémoire allouée en utilisant
 *  l'outil \c valgrind de la manière suivante :
 *
\code
valgrind --leak-check=full ./test-Liste
\endcode
 * 
 * Lorsque vos listes fonctionnent correctement, vous pouvez les adapter afin de
 * les utiliser pour représenter efficacement la grille de jeu de votre Tetris. 
 * Chaque noeud de votre liste représentera une ligne du jeu tetris, la première
 * ligne (celle du bas) étant la première cellule utile de votre liste chaînée.
 * Supprimer une ligne se fera donc en supprimant la cellule correspondante et vous
 * devrez rajouter une ligne composée d'espaces en fin de liste. Voilà à quoi ressemble
 * votre liste pour représenter le tetris ci-contre.
 * 
\verbatim
||        ||
...
||   l    ||
||  @l$$  ||
|| @@@$$  ||
\endverbatim
 *
 * \image html liste-chainee-tetris-small.png
 *
 * 
 * - Définissez un type pour représenter chacune des lignes de la grille de jeu.
 *
 * - Redéfinissez le type Grille de manière à remplacer le tableau par une
 *   liste chaînée dont chaque cellule représente une ligne de la grille.
 *
 * À ce stade, la compilation de votre programme échouera. C'est normal. Il faut
 * maintenant modifier les procédures qui manipulent la grille de jeu.
 *
 * - Afin de pouvoir compiler votre code, commentez le corps des procédures \c
 *  ecrireCase et \c lireCase. Il peut s'avérer pratique d'ajouter un return
 *  bidon (ex : \c return ' ';) à la procédure lireCase.
 *
 * Votre programme devrait maintenant compiler à nouveau tout en restant
 * inutilisable.
 *
 * - Écrivez une procédure \c construireGrille qui construit la grille de jeu.
 * 
 * - Écrivez une procédure \c détruireGrille qui libère la mémoire occupée par
 *  la grille.
 *
 * - Modifiez le corps des procédures \c lireCase et \c ecrireCase
 *  afin de les adapter à la nouvelle structure de données employée
 *  pour la grille de jeu. Ces dexu procédures nécessite de parcourir
 *  la liste pour arriver à la bonne ligne.
 *
 * Votre programme devrait maintenant être redevenu fonctionnel.
 *
 * - Modifier le corps de la procédure \c supprimerLigne de manière à ne plus
 *   recopier la grille case par case mais plutôt en supprimant l'élément
 *   approprié de la liste chaînée et en ajoutant une nouvelle ligne vide en
 *   bout de liste.
 *
 * - Renommez votre fichier source 
 *
 *   \code
     tp2-[votre nom]-liste.c
     \endcode
 * 
 * - Tout devrait fonctionner.
 *
 * - Si vous avez terminé les étapes précédentes et que tout
 *   fonctionne bien, vous pouvez améliorer votre code en modifiant
 *   les procédures \c afficherGrille, \c initialiser, \c ecrirePiece
 *   et \c hauteurMax afin de remplacer les appels à \c ecrireCase, \c
 *   lireCase par une utilisation séquentielle de la liste chaînée.
 *
 *
 * \section TP2-bonus 5 - Améliorations optionnelles
 *
 * - Vous pouvez rajouter des couleurs sur votre console, voir par exemple le TP précédent (\ref onze) qui vous met un joli tableau des couleurs possibles.
 *
 * \code
#define COLOR(X) printf("\033["X"m")
...
// essayez 40, 41, 42, 43 ... et 0 pour revenir à par défaut.
if (c == '#') { COLOR("41"); printf( " " ); }
 * \endcode
 *
 * - N'oubliez pas de faire un certain nombre de pièces distinctes, c'est plus sympa pour jouer.
 *
 * - Vous pouvez apporter tout autre modification qui rendra votre
 *   programme plus semblable au ``vrai`` Tetris ;-): toutes les
 *   pièces, score (en fonction du nombre de lignes supprimé en même
 *   temps). L'aspect temps réél sera abordé dans le TP suivant.
 * 
 *
 * \section TP2-divers 6 - Notes
 * 
 * - Pour tester plus facilement votre tetris, n'oubliez pas la pièce
 *   *verticale* dans la liste des pièces possibles.
 *
 * - Ayez une version *fonctionnelle* du tetris tableau, avant de
 *   faire la version liste. Vous aurez besoin d'une version
 *   fonctionnelle pour le tetris graphique.
 *
 * - Dans la version liste du Tetris, une erreur commune est
 *   d'initialiser chaque ligne par une affectation à la chaîne
 *   <tt>"____________"</tt> (où les '_' sont des espaces).  Le
 *   problème est que c'est une chaîne constante, donc non
 *   modifiable. Il faut donc bien allouer \b dynamiquement une chaîne
 *   de la bonne longueur et la remplir d'espaces.
 *
 */

