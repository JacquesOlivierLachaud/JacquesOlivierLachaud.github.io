#include "GrayLevelImage2D.hpp"

GrayLevelImage2D::GrayLevelImage2D()
  : m_data(), m_width(0), m_height(0)
{
}

GrayLevelImage2D::GrayLevelImage2D( int w, int h, GrayLevel g)
{
  // TODO
}
void
GrayLevelImage2D::fill( GrayLevel g )
{
  // TODO
}

/// @return la largeur de l'image.
int
GrayLevelImage2D::w() const
{
  return m_width;
}
/// @return la hauteur de l'image.
int
GrayLevelImage2D::h() const
{
  return m_height;
}

/**
   Accesseur read-only à la valeur d'un pixel.
   @return la valeur du pixel(i,j)
*/
GrayLevelImage2D::GrayLevel
GrayLevelImage2D::at( int i, int j ) const
{
  // TODO
}

/**
   Accesseur read-write à la valeur d'un pixel.
   @return une référence à la valeur du pixel(i,j)
*/
GrayLevelImage2D::GrayLevel&
GrayLevelImage2D::at( int i, int j )
{
  // TODO
}


