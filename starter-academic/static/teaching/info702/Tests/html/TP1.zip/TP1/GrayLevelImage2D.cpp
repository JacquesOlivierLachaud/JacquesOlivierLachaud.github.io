#include <sstream>
#include "GrayLevelImage2D.hpp"

///////////////////////////////////////////////////////////////////////////////
// class GrayLevelImage2D
///////////////////////////////////////////////////////////////////////////////


GrayLevelImage2D::GrayLevelImage2D()
  : m_width( 0 ), m_height( 0 )
{}

GrayLevelImage2D::GrayLevelImage2D( int w, int h, GrayLevel g )
  : m_width( w ), m_height( h )
{
  // To do: initialize m_data
}

int
GrayLevelImage2D::w() const
{ return m_width; }

int
GrayLevelImage2D::h() const
{ return m_height; }

int
GrayLevelImage2D::index( int x, int y ) const
{
  // TODO
}
