#include <cassert>
#include <iostream>
#include <stdexcept>
#include "GrayLevelImage2D.hpp"

int main()
{
  GrayLevelImage2D img(8, 8, 5); // imagette 8 × 8 remplie de 5
  assert(img.w() == 8 && img.h() == 8);
  for (int y = 0; y < img.h(); ++y) {
    for (int x = 0; x < img.w(); ++x) {
      assert(img.at(x, y) == 5);
      // La conversion affiche un entier plutôt qu'un caractère.
      std::cout << ' ' << int(img.at(x, y));
    }
    std::cout << '\n';
  }

  img.at(2, 3) = 42; // modification d'un pixel par référence
  const GrayLevelImage2D& cimg = img;
  assert(cimg.at(2, 3) == 42); // accès en lecture sur une image constante

  GrayLevelImage2D copie = img;
  copie.at(2, 3) = 7;
  assert(cimg.at(2, 3) == 42); // la copie possède ses propres pixels
  copie.fill(12);
  for (int y = 0; y < copie.h(); ++y)
    for (int x = 0; x < copie.w(); ++x)
      assert(copie.at(x, y) == 12);

  GrayLevelImage2D vide;
  assert(vide.w() == 0 && vide.h() == 0);
  bool exceptionRecue = false;
  try {
    img.at(img.w(), 0); // cette abscisse est hors de l'image
  } catch (const std::out_of_range&) {
    exceptionRecue = true;
  }
  assert(exceptionRecue);
  std::cout << "Tests de la partie 2 passes.\n";
}
