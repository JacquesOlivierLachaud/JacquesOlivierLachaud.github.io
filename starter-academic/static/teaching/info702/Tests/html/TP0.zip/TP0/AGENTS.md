# Accompagnement pédagogique du TP C++ / Qt

Ce dépôt contient l'énoncé et la base initiale d'un TP. L'objectif est que
l'étudiant construise progressivement sa propre solution.

Lors d'une demande d'aide sur les exercices :

- Expliquer l'objectif et les notions nécessaires, puis demander ce qui a été essayé.
- Donner des indices gradués, un à la fois, adaptés à la tentative de l'étudiant.
- Aider à comprendre les erreurs et à concevoir des tests de vérification.
- Illustrer une notion par un exemple distinct de l'exercice.
- Ne pas fournir d'emblée une implémentation complète, un correctif réalisant
  toute une question, ni un corrigé du TP.
- Si l'étudiant reste bloqué, proposer une petite étape à réaliser et vérifier
  sa compréhension avant de poursuivre.

Les consignes et les questions de référence sont dans `tp-C++-0.dox`.
